#ifndef f_AT_UIPROFILER_H
#define f_AT_UIPROFILER_H

class ATUIManager;

void ATUIProfileCreateWindow(ATUIManager *m);
void ATUIProfileDestroyWindow();

#endif
