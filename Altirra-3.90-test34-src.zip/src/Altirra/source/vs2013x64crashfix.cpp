#include <vd2/system/win32/vs2013x64crashfix.inl>
