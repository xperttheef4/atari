//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AltirraShell.rc
//
#define IDD_SERIAL_OPTIONS              101
#define IDR_LOG_MENU                    102
#define IDD_DISKDRIVE_PANEL             103
#define IDD_DISKDRIVE_PARENT            104
#define IDD_PANEL_EXELOADER             105
#define IDD_PANEL_DISKOPTIONS           106
#define IDC_SERIAL_PORT                 1001
#define IDC_PATH                        1003
#define IDC_BROWSE                      1004
#define IDC_STATIC_LABEL                1005
#define IDC_EJECT                       1006
#define IDC_MODE                        1007
#define IDC_EXPAND                      1009
#define IDC_TIMINGMODE                  1010
#define IDC_HS_DISABLED                 1011
#define IDC_HS_STANDARD                 1012
#define IDC_HS_CUSTOM                   1013
#define IDC_BAUDRATE                    1014
#define IDC_DIVISOR                     1015
#define IDC_CHECK1                      1017
#define IDC_AUTODISABLEBASIC            1017
#define ID_CONTEXT_CLEARALL             40001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
