#ifndef f_STDAFX_H
#define f_STDAFX_H

struct IUnknown;

#include <windows.h>
#include <commctrl.h>
#include <tchar.h>
#include <vd2/system/vdtypes.h>

#endif
