#ifndef f_STDAFX_H
#define f_STDAFX_H

struct IUnknown;

#include <vd2/system/vdtypes.h>

#endif
